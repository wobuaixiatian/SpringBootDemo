package com.hb.demo.controller;

import com.hb.demo.mapper.StudentMapper;
import com.hb.demo.vo.StudentVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("test")
public class TestController {

    @Autowired
    private StudentMapper studentMapper;

    @PostMapping(value = "getString")
    public String getString(@RequestBody String param) {
        return "Hello ," + param;
    }

    @PostMapping(value = "getObject")
    public String getObject(@RequestBody StudentVo studentVo) {
        return "Hello ," + studentVo.getName();
    }

    @PostMapping(value = "saveStudentToDB")
    public String saveStudentToDB(@RequestBody StudentVo studentVo) {
        studentMapper.insert(studentVo);
        return "Hello ," + studentVo.getName();
    }

    @PostMapping(value = "getStudentFromDB")
    public List<StudentVo> getStudentFromDB(@RequestBody StudentVo studentVo) {
        Map<String, Object> param = new HashMap<>();
        param.put("name", "hubo");
        List<StudentVo> studentVoList = studentMapper.selectByMap(param);
        return studentVoList;
    }
}
