package com.hb.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hb.demo.vo.StudentVo;
import org.apache.ibatis.annotations.Mapper;

/**
 * 学生信息表(student)数据Mapper
 *
 * @author hubo
 * @since 2023-04-10 23:00:03
 * @description 由 Mybatisplus Code Generator 创建
*/
@Mapper
public interface StudentMapper extends BaseMapper<StudentVo> {

}
