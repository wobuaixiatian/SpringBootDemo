package com.hb.demo.dao;

import com.hb.demo.vo.StudentVo;
import lombok.extern.slf4j.Slf4j;
import com.hb.demo.mapper.StudentMapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Repository;

/**
 * 学生信息表(student)数据DAO
 *
 * @author hubo
 * @since 2023-04-10 23:00:03
 * @description 由 Mybatisplus Code Generator 创建
 */
@Slf4j
@Repository
public class StudentDao extends ServiceImpl<StudentMapper, StudentVo> {

}