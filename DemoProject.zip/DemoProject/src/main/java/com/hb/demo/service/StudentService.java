package com.hb.demo.service;


/**
 * 学生信息表服务接口
 *
 * @author hubo
 * @since 2023-04-10 23:00:03
 * @description 由 Mybatisplus Code Generator 创建
 */
public interface StudentService {

}
