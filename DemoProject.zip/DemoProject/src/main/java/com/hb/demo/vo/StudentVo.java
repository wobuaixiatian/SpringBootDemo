package com.hb.demo.vo;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
@TableName("student")
@Data
public class StudentVo {
    private String name;

    private String age;

    private String classRoom;

    private int grade;

    private String address;
}
