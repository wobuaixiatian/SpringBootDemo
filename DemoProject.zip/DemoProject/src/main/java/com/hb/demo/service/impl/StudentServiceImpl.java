package com.hb.demo.service.impl;

import com.hb.demo.dao.StudentDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.hb.demo.service.StudentService;
import org.springframework.stereotype.Service;

/**
 * 学生信息表服务接口实现
 *
 * @author hubo
 * @since 2023-04-10 23:00:03
 * @description 由 Mybatisplus Code Generator 创建
 */
@Slf4j
@RequiredArgsConstructor
@Service
public class StudentServiceImpl implements StudentService {
    private final StudentDao studentDao;

}